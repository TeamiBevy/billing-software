﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;

namespace Cool
{
    class User1
    {
        //COCONUT
        public static void coconutlitre(String d, decimal half, decimal one, decimal two, decimal five)
        {
            string query10 = "insert into coconutlitre values('" + d + "','" + half + "','" + one + "','" + two + "','"+five+"')";

            try
            {
                MySqlCommand cmd10 = new MySqlCommand(query10, Database1.connection);
                cmd10.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Updated Successfuly");

            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }


        }

        //GROUNDNUT

        public static void groundnutlitre(String d, decimal half, decimal one, decimal two, decimal five)
        {
            string query10 = "insert into groundnutlitre values('" + d + "','" + half + "','" + one + "','" + two + "','" + five + "')";
            try
            {
                MySqlCommand cmd10 = new MySqlCommand(query10, Database1.connection);
                cmd10.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Updated Successfuly");

            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }


        }
        //SESAME

        public static void sesamelitre(String d, decimal half, decimal one, decimal two, decimal five)
        {

            string query10 = "insert into groundnutlitre values('" + d + "','" + half + "','" + one + "','" + two + "','" + five + "')";
            try
            {
                MySqlCommand cmd10 = new MySqlCommand(query10, Database1.connection);
                cmd10.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("Updated Successfuly");

            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }

        }
        

    }
}
