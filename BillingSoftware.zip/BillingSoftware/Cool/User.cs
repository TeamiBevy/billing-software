﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
namespace Cool
{
    public class User
    {

        string name;
        public static string points;
        decimal total;
        static string d = DateTime.Now.ToString("dd-MM-yyyy");
        User p;
        static string pt;
       public static decimal pts=0;


        public static void billing(String number, String name, decimal total, decimal points)
        {
            string query = "select * from billingdetails";
           
            MySqlCommand cmd = new MySqlCommand(query, Database1.connection);

            MySqlDataReader reader = cmd.ExecuteReader();
            int f = 0;
            while (reader.Read())
            {
                if (number.Equals(reader.GetString("customer_number")))
                {
                    pt = reader.GetString("points").ToString();
                    f = 1;


                }

            }
            reader.Close();
            pts = Convert.ToDecimal(pt);
            pts += points;
            if (f == 1)
            {
                d = d + "#" + total;
                string query20 = "update billingdetails set date_and_total='" + d + "',points='" +pts+ "' where customer_number='" + number + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }

            }
            else
            {
                d = d + "#" + total;
                string query10 = "insert into billingdetails values(NULL,'" + number + "','" + name + "','" + d + "','" + points + "'3)";

                try
                {
                    MySqlCommand cmd10 = new MySqlCommand(query10, Database1.connection);
                    cmd10.ExecuteNonQuery();

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }

            }

        }
        public static void select(String number)
        {
            string query = "select * from billingdetails";
            MySqlCommand cmd = new MySqlCommand(query, Database1.connection);

            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if (number.Equals(reader.GetString("customer_number")))
                {
                    points = reader.GetString("points").ToString();

                }
            }
            reader.Close();

        }


        public static void pointtab(decimal ppoints, string num)
        {
            if (ppoints == 0)
            {
                try
                {
                    string query1 = "update billingdetails set points='" + ppoints + "' where customer_number='" + num + "' ";
                    MySqlCommand cmd2 = new MySqlCommand(query1, Database1.connection);

                    cmd2.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);


                }
            }
            else
            {
                try
                {
                    decimal x = Convert.ToDecimal(points);
                    string query1 = "update billingdetails set points='" + ppoints + "' where customer_number='" + num + "' ";
                    MySqlCommand cmd3 = new MySqlCommand(query1, Database1.connection);

                    cmd3.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }

        }
        //TOTAL UPDATE
        public static void totaloil(String date, decimal coco, decimal gnd, decimal sesame)
        {

            string query = "select * from totaloil";
            MySqlCommand cmd = new MySqlCommand(query, Database1.connection);

            MySqlDataReader reader = cmd.ExecuteReader();
            int f = 0;
            while (reader.Read())
            {
                if (date.Equals(reader.GetString("date")))
                {
                    f = 1;

                }

            }
            reader.Close();
            if (f == 1)
            {

                string query20 = "update totaloil set coconut='" + coco + "',groundnut='" + gnd + "',sesame='" + sesame + "' where date='" + date + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfuly");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }
            else
            {

                string query10 = "insert into totaloil values('" + date + "','" + coco + "','" + gnd + "','" + sesame + "')";

                try
                {
                    MySqlCommand cmd10 = new MySqlCommand(query10, Database1.connection);
                    cmd10.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfuly");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }


            }

        }

    }
}
