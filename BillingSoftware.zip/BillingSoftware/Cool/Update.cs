﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cool
{
    public partial class Update : Form
    {
        decimal value;
        public Update()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text.Equals("Coconut Oil") || comboBox1.Text.Equals("Groundnut Oil") || comboBox1.Text.Equals("Sesame Oil"))
            {

                comboBox2.Enabled = true;

            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if(comboBox1.Text.Equals("Coconut Oil"))
            {
                if (comboBox2.Text.Equals("1/2"))
                {
                    Change.Modify(value, 0, 0, 0, 0, 0, 0, 0);
                }
                if (comboBox2.Text.Equals("1"))
                {
                    Change.Modify(0,value, 0, 0, 0, 0, 0, 0);

                }
            }
            if (comboBox1.Text.Equals("Groundnut Oil"))
            {
                if (comboBox2.Text.Equals("1/2"))
                {
                    Change.Modify(0, 0, value, 0, 0, 0, 0, 0);

                }
                if (comboBox2.Text.Equals("1"))
                {
                    Change.Modify(0, 0, 0, value, 0, 0, 0, 0);

                }



            }
            if (comboBox1.Text.Equals("Sesame Oil"))
            {
                if (comboBox2.Text.Equals("1/2"))
                {
                    Change.Modify(0, 0, 0, 0, value, 0, 0, 0);

                }
                if (comboBox2.Text.Equals("1"))
                {
                    Change.Modify(0, 0, 0, 0, 0, value, 0, 0);

                }

            }
            if (comboBox1.Text.Equals("Tax"))
            {

                Change.Modify(0, 0, 0, 0, 0, 0, value, 0);

            }
            if (comboBox1.Text.Equals("Points"))
            {
                Change.Modify(0, 0, 0, 0, 0, 0, 0, value);



            }








        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                value = Convert.ToDecimal(textBox1.Text);

            }
            catch (Exception w)
            {

            }
        }

        private void Update_Load(object sender, EventArgs e)
        {
            comboBox2.Enabled = false;

        }
    }
}
