﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;

namespace Cool
{
    class Production
    {
        static String word = "hello";
        public static void coco(decimal hc, decimal oc, decimal tc, decimal fc)
        {

            String halfc = null, onec = null, twoc = null, fivec = null;
            decimal half_c, one_c, two_c, five_c;
            string query = "select * from availablecoconut";
            Database1.Open();
            MySqlCommand cmd = new MySqlCommand(query, Database1.connection);

            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if (word.Equals(reader.GetString("date")))
                {
                    halfc = reader.GetString("half").ToString();
                    onec = reader.GetString("one").ToString();

                    twoc = reader.GetString("two").ToString();
                    fivec = reader.GetString("five").ToString();


                }
            }
            reader.Close();
            half_c = Convert.ToDecimal(halfc);
            one_c = Convert.ToDecimal(onec);
            two_c = Convert.ToDecimal(twoc);
            five_c = Convert.ToDecimal(fivec);
            half_c -= hc;
            one_c -= oc;
            two_c -= tc;
            five_c -= fc;
            string query20 = "update availablecoconut set half='" + half_c + "',one='" + one_c + "',two='" + two_c + "',five='" + five_c + "' where date='" + word + "' ";

            try
            {
                MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                cmd20.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }

        }
        //GROUNDNUT
        public static void gnd(decimal hg, decimal og, decimal tg, decimal fg)
        {

            String halfg = null, oneg = null, twog = null, fiveg = null;
            decimal half_g, one_g, two_g, five_g;
            string query = "select * from availablegroundnut";
            Database1.Open();
            MySqlCommand cmd = new MySqlCommand(query, Database1.connection);

            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if (word.Equals(reader.GetString("date")))
                {
                    halfg = reader.GetString("half").ToString();
                    oneg = reader.GetString("one").ToString();

                    twog = reader.GetString("two").ToString();
                    fiveg = reader.GetString("five").ToString();


                }
            }
            reader.Close();
            half_g = Convert.ToDecimal(halfg);
            one_g = Convert.ToDecimal(oneg);
            two_g = Convert.ToDecimal(twog);
            five_g = Convert.ToDecimal(fiveg);
            half_g -= hg;
            one_g -= og;
            two_g -= tg;
            five_g -= fg;
            string query20 = "update availablegroundnut set half='" + half_g + "',one='" + one_g + "',two='" + two_g + "',five='" + five_g + "' where date='" + word + "' ";

            try
            {
                MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                cmd20.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }

        }

        //SESAME
        public static void sesame(decimal hs, decimal os, decimal ts, decimal fs)
        {

            String halfs = null, ones = null, twos = null, fives = null;
            decimal half_s, one_s, two_s, five_s;
            string query = "select * from availablesesame";
            Database1.Open();
            MySqlCommand cmd = new MySqlCommand(query, Database1.connection);

            MySqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                if (word.Equals(reader.GetString("date")))
                {
                    halfs = reader.GetString("half").ToString();
                    ones = reader.GetString("one").ToString();

                    twos = reader.GetString("two").ToString();
                    fives = reader.GetString("five").ToString();


                }
            }
            reader.Close();
            half_s = Convert.ToDecimal(halfs);
            one_s = Convert.ToDecimal(ones);
            two_s = Convert.ToDecimal(twos);
            five_s = Convert.ToDecimal(fives);
            half_s -= hs;
            one_s -= os;
            two_s -= ts;
            five_s -= fs;
            string query20 = "update availablesesame set half='" + half_s + "',one='" + one_s + "',two='" + two_s + "',five='" + five_s + "' where date='" + word + "' ";

            try
            {
                MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                cmd20.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                System.Windows.Forms.MessageBox.Show(e.Message);

            }

        }





    }
}
