﻿namespace Cool {
    
    
    public partial class DataSet1 {
    }
}

namespace Cool.DataSet1TableAdapters {
    
    
    public partial class BillingSystemTableAdapter {
    }
}
