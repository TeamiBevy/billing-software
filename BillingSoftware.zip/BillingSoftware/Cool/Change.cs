﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;

namespace Cool
{
    class Change
    {

        public static decimal halfc, onec, halfg, oneg, halfs, ones, points, t;
        static String word = "hello";
        public static void Modify(decimal hc, decimal oc, decimal hg, decimal og, decimal hs, decimal os, decimal tax, decimal pt)
        {
            if (hc > 0)
            {
                string query20 = "update update set coco_half='" + hc + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }
            if (oc > 0)
            {
                string query20 = "update update set coco_one='" + oc + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }


            if (hg > 0)
            {
                string query20 = "update update set gnd_half='" + hg + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }
            if (og > 0)
            {
                string query20 = "update update set gnd_one='" + og + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }



            if (hs > 0)
            {
                string query20 = "update update set sesa_half='" + hs + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }
            if (os > 0)
            {
                string query20 = "update update set sesa_one='" + os + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }

            if (tax > 0)
            {
                string query20 = "update update set tax='" + tax + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            } 
            if (pt > 0)
            {
                string query20 = "update update set points='" + pt + "' where date='" + word + "' ";

                try
                {
                    MySqlCommand cmd20 = new MySqlCommand(query20, Database1.connection);
                    cmd20.ExecuteNonQuery();
                    System.Windows.Forms.MessageBox.Show("Updated Successfully");

                }
                catch (Exception e)
                {
                    System.Windows.Forms.MessageBox.Show(e.Message);

                }
            }




        }



    }
}
