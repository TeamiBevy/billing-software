﻿using Cool.Model;
using Cool.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data.OleDb;



namespace Cool
{
    public partial class Form1 : Form
    {

        int no=100001;
        public decimal TotalCoconut=0, TotalGroundnut=0, TotalSesame=0, TotalCoconutseedcake=0, TotalGroundnutseedcake=0, TotalSesameseedcake = 0;
        public decimal pt;



        decimal halfc, onec, twoc, fivec;
        decimal halfg, oneg, twog, fiveg;
        decimal halfs, ones, twos, fives;
        String address;
        public decimal coconut_oil, groundnut_oil, sesame_oil;
        decimal Totalvalue,quantity,price,TotalAmount,TotalAmount1;
        decimal TotalTax=0,q;
        String d;
        public Form1()
        {
            InitializeComponent();

            //DATE
            
            label4.Text = DateTime.Now.ToString("dd-MM-yyyy");
            d= DateTime.Now.ToString("dd-MM-yyyy");
           
        
        }
        private List<Cart> shopping=new List<Cart>();
        private void button1_Click(object sender, EventArgs e)
        {

            if (IsValidated())
            {
                Cart c = new Cart()
                {
                    ItemName = comboBox1.Text,
                    Litre=comboBox2.Text,
                    Price = price,
                    Quantity = Convert.ToDecimal(QuantitytextBox.Text),
                    
                    Total = TotalAmount


                };

                shopping.Add(c);
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = shopping;

                TotalAmount = shopping.Sum(x => x.Total);
                TotalPaytextBox.Text = TotalAmount.ToString();
                TaxtextBox.Text = TotalTax.ToString();
                pt = TotalAmount*Convert.ToDecimal(0.02);
                TotalAmounttextBox.Text = (TotalAmount).ToString();

                comboBox1.SelectedIndex = -1;
                comboBox2.SelectedIndex = -1;
                PricetextBox.Clear();
                QuantitytextBox.Clear();
                TotaltextBox.Clear();
                q = 0;

            }
            
               
            

        }
        private bool IsValidated()
        {
            if (NametextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Customer Name Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                NametextBox.Focus();
                return false;
            }
            if (NumbertextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Contact Number Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                NumbertextBox.Focus();
                return false;
            }
            if (NumbertextBox.Text.Length != 10)
            {
                MessageBox.Show("Contact Number Should have 10 digits", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                NumbertextBox.Focus();
                return false;

            }
            if (richTextBox1.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Address Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                NumbertextBox.Focus();
                return false;

            }
            if (comboBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Select Atleast One Item", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            if (QuantitytextBox.Text.Trim() == string.Empty)
            {
                MessageBox.Show("Quantity Required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                QuantitytextBox.Focus();
                return false;
            }
            else
            {
                
                bool isDecimal = decimal.TryParse(QuantitytextBox.Text.Trim(), out quantity);

                if (!isDecimal)
                {
                    MessageBox.Show("Quantity should be Interger Value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    QuantitytextBox.Clear();
                    QuantitytextBox.Focus();
                    return false;
                }

            }

            return true;

        }

        private void NewOrderButton_Click(object sender, EventArgs e)
        {
            NewOrderButton.Enabled = false;
            PrintOrderButton.Enabled = true;
            PrintPreviewButton.Enabled = true;
            CancelOrderButton.Enabled = true;

            ItemGroupBox.Enabled = true;
            NametextBox.Focus();
        }

        private void CancelOrderButton_Click(object sender, EventArgs e)
        {

            DialogResult dialog = MessageBox.Show("Do you want to Cancel the Order?", "Exit", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {
                NewOrderButton.Enabled = true;
                PrintOrderButton.Enabled = false;
                PrintPreviewButton.Enabled = false;
                CancelOrderButton.Enabled = false;

                ItemGroupBox.Enabled = false;

                NametextBox.Clear();
                NumbertextBox.Clear();
                richTextBox1.Clear();
                comboBox1.SelectedIndex = -1;
                PricetextBox.Clear();
                QuantitytextBox.Clear();
                TotaltextBox.Clear();

                TotalAmount = 0;
                TotalTax = 0;
                Totalvalue = 0;

                TaxtextBox.Clear();
                TotalPaytextBox.Clear();
                TotalAmounttextBox.Clear();
                dataGridView1.DataSource = null;
                shopping.Clear();
                pt = 0;

         
            }

            else if (dialog == DialogResult.No)
            {

            }
        }

        private void NametextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void NumbertextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
               
            
        }

        private void QuantitytextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                quantity = Convert.ToDecimal(QuantitytextBox.Text);
            }
            catch (Exception m)
            {
               
            }
            
            

            if (comboBox1.Text.Equals("Coconut Oil"))
            {
                if (comboBox2.Text.Equals("1/2"))
                {
                    halfc += quantity;
                }
                if (comboBox2.Text.Equals("1"))
                {
                    onec += quantity;

                }
                if (comboBox2.Text.Equals("2"))
                {
                    twoc += quantity;

                }
                if (comboBox2.Text.Equals("5"))
                {
                    fivec += quantity;

                }
                
            }
            else if (comboBox1.Text.Equals("Groundnut Oil"))
            {

                if (comboBox2.Text.Equals("1/2"))
                {
                    halfg += quantity;

                }
                if (comboBox2.Text.Equals("1"))
                {
                    oneg += quantity;

                }
                if (comboBox2.Text.Equals("2"))
                {
                    twog += quantity;

                }
                if (comboBox2.Text.Equals("5"))
                {
                    fiveg += quantity;

                }
            }
            else if (comboBox1.Text.Equals("Sesame Oil"))
            {

                if (comboBox2.Text.Equals("1/2"))
                {
                    halfs += quantity;

                }
                if (comboBox2.Text.Equals("1"))
                {
                    ones += quantity;

                }
                if (comboBox2.Text.Equals("2"))
                {
                    twos += quantity;

                }
                if (comboBox2.Text.Equals("5"))
                {
                    fives += quantity;

                }
            }
            
            TotalAmount = quantity * price;
            TotaltextBox.Text= TotalAmount.ToString();
         




        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            String item1 = dataGridView1.Rows[index].Cells[0].Value.ToString();
            String item2 = dataGridView1.Rows[index].Cells[1].Value.ToString();
            String m = dataGridView1.Rows[index].Cells[3].Value.ToString();
            decimal m1 = Convert.ToDecimal(m);


            if (item1.Equals("Coconut Oil"))
            {
                if (item2.Equals("1/2"))
                {
                    halfc -= m1;
                }
                if (item2.Equals("1"))
                {
                    onec -= m1;

                }
                if (item2.Equals("2"))
                {
                    twoc -= m1;

                }
                if (item2.Equals("5"))
                {
                    fivec -= m1;

                }

            }
            else if (item1.Equals("Groundnut Oil"))
            {

                if (item2.Equals("1/2"))
                {
                    halfg -= m1;

                }
                if (item2.Equals("1"))
                {
                    oneg -= m1;

                }
                if (item2.Equals("2"))
                {
                    twog -= m1;

                }
                if (item2.Equals("5"))
                {
                    fiveg -= m1;

                }
            }
            else if (item1.Equals("Sesame Oil"))
            {

                if (item2.Equals("1/2"))
                {
                    halfs -=m1;

                }
                if (item2.Equals("1"))
                {
                    ones -= m1;

                }
                if (item2.Equals("2"))
                {
                    twos -= m1;

                }
                if (item2.Equals("5"))
                {
                    fives -= m1;

                }
            }
            





            shopping.RemoveAt(index);

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = shopping;
            TotalAmount = shopping.Sum(x => x.Total);
            TotalPaytextBox.Text = TotalAmount.ToString();
            
            
        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void dataGridView1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {

                var hti = dataGridView1.HitTest(e.X, e.Y);
                dataGridView1.Rows[hti.RowIndex].Selected = true;

                contextMenuStrip1.Show(dataGridView1, e.X, e.Y);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
           no++;

            Image logo = Resources.logo;
            e.Graphics.DrawImage(logo, 40,40,190,190);
            e.Graphics.DrawString("M3 Oils & Food Products",
                new Font("Times New Roman", 30, FontStyle.Bold),
              Brushes.ForestGreen,
              new Point(240, 70));
            e.Graphics.DrawString("4/371/3, G.V.Building, R.K.Gardens,",
                new Font("Times New Roman", 20, FontStyle.Regular),
              Brushes.Black,
              new Point(240, 130));
            e.Graphics.DrawString("Thirumoorthi malai Road,",
                new Font("Times New Roman", 20, FontStyle.Regular),
              Brushes.Black,
              new Point(240, 170));
            e.Graphics.DrawString("Udumalpet-642112",
                new Font("Times New Roman", 20, FontStyle.Regular),
              Brushes.Black,
              new Point(240, 210));
            e.Graphics.DrawString("Customer Care: 8344344443",
                new Font("Times New Roman", 20, FontStyle.Regular),
              Brushes.Black,
              new Point(240, 250));
             

            e.Graphics.DrawString("Date : " + DateTime.Now.ToShortDateString(), new Font("Arial", 12, FontStyle.Regular),
                Brushes.Black,
                new Point(600, 300));
            e.Graphics.DrawString("Customer Name : " + NametextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Regular),
                Brushes.Black,
                new Point(25, 300));
            e.Graphics.DrawString("Customer Number : " + NumbertextBox.Text.Trim(), new Font("Arial", 12, FontStyle.Regular),
                Brushes.Black,
                new Point(25, 330));
            int x=360;
            e.Graphics.DrawString("Address : " + richTextBox1.Text.Trim(), new Font("Arial", 12, FontStyle.Regular),
                Brushes.Black,
                new Point(25, x));
            e.Graphics.DrawString("Bill No:  CO"+no, new Font("Arial", 12, FontStyle.Regular),
                Brushes.Black,
                new Point(25, 400));
            e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------------",
                 new Font("Arial", 12, FontStyle.Regular),
               Brushes.Black,
               new Point(25, 420));

            e.Graphics.DrawString("Item Name : ", new Font("Arial", 12, FontStyle.Regular),
               Brushes.Black,
               new Point(25, 440));
            e.Graphics.DrawString("Litre : ", new Font("Arial", 12, FontStyle.Regular),
               Brushes.Black,
               new Point(300, 440));
            e.Graphics.DrawString("Price : ", new Font("Arial", 12, FontStyle.Regular),
               Brushes.Black,
               new Point(425, 440));
            e.Graphics.DrawString("Quantity : ", new Font("Arial", 12, FontStyle.Regular),
               Brushes.Black,
               new Point(550, 440));
            e.Graphics.DrawString("Total : ", new Font("Arial", 12, FontStyle.Regular),
             Brushes.Black,
             new Point(675, 440));
            e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------------",
                new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(25, 460));

            //LOOP
            int yPos = 490;
            foreach (var i in shopping)
            {
                e.Graphics.DrawString(i.ItemName, new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(25, yPos));
                e.Graphics.DrawString(i.Litre.ToString(), new Font("Arial", 12, FontStyle.Regular),
             Brushes.Black,
             new Point(300, yPos));
                e.Graphics.DrawString(i.Price.ToString(), new Font("Arial", 12, FontStyle.Regular),
             Brushes.Black,
             new Point(425, yPos));
                e.Graphics.DrawString(i.Quantity.ToString(), new Font("Arial", 12, FontStyle.Regular),
             Brushes.Black,
             new Point(550, yPos));
                e.Graphics.DrawString(i.Total.ToString(), new Font("Arial", 12, FontStyle.Regular),
            Brushes.Black,
            new Point(675, yPos));
                yPos += 30;

            }
            e.Graphics.DrawString("---------------------------------------------------------------------------------------------------------------------------------",
                new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(25, yPos + 30));
            e.Graphics.DrawString("Total : ", new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(460, yPos + 60));
            e.Graphics.DrawString(TotalPaytextBox.Text, new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(600, yPos + 60));


            e.Graphics.DrawString("Total Tax : ", new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(460, yPos + 90));
            e.Graphics.DrawString(TotalTax.ToString(), new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(600, yPos + 90));

            e.Graphics.DrawString("TOTAL AMOUNT : ", new Font("Arial", 12, FontStyle.Regular),
             Brushes.Black,
             new Point(450, yPos + 130));
            e.Graphics.DrawString(TotalAmounttextBox.Text, new Font("Arial", 12, FontStyle.Regular),
              Brushes.Black,
              new Point(600, yPos + 130));
            e.Graphics.DrawString("Signature ", new Font("Arial", 12, FontStyle.Regular),
            Brushes.Black,
            new Point(25, yPos + 180));



        }

        private void printPreviewDialog1_Load(object sender, EventArgs e)
        {
            
        }

        private void PrintPreviewButton_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void TotaltextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PrintOrderButton_Click(object sender, EventArgs e)
        {
            string p;
            DialogResult dialog = MessageBox.Show("Do you want to Save the Order?", "Exit", MessageBoxButtons.YesNo);
            if (dialog == DialogResult.Yes)
            {

                Database1.Open();
                User.billing(NumbertextBox.Text,NametextBox.Text, TotalAmount, pt);
                //decimal t = Convert.ToDecimal(User.points);
               // MessageBox.Show("Points cuureent'" + pt + "'");
                //decimal c = pt + t;
                //User.pointtab(c, NumbertextBox.Text);

                //User.select(NumbertextBox.Text);

                // User1.coconutlitre(d, halfc, onec, twoc, fivec);
                Production.coco(halfc, onec, twoc, fivec);

                //User1.groundnutlitre(d, halfg, oneg,twog,fiveg);
                Production.gnd(halfg, oneg, twog, fiveg);

                //User1.sesamelitre(d, halfs, ones, twos, fives);
                Production.sesame(halfs, ones, twos, fives);
                TotalSesameseedcake = 0;
                TotalGroundnutseedcake = 0;

                TotalCoconutseedcake = 0;

                TotalSesame = 0;
                TotalGroundnut = 0;
                TotalCoconut = 0;

                halfg = 0;
                halfc = 0;
                halfs = 0;

                onec = 0;
                oneg = 0;
                ones = 0;

                twoc = 0;
                twog = 0;
                twos = 0;

                fivec = 0;
                fiveg = 0;
                fives = 0;
                 DialogResult dialog1 = MessageBox.Show("You Have '"+User.pts+"' points", "Exit", MessageBoxButtons.YesNo);


                 if (dialog1 == DialogResult.Yes)
                 {
                     decimal m = Convert.ToDecimal(User.points);
                     TotalAmount = TotalAmount-(TotalAmount * (m/100));
                     TotalAmounttextBox.Text = TotalAmount.ToString();
                    User.pointtab(0, NumbertextBox.Text);

                 }
                 else
                 {
                   

                 }
                //TOTAL UPDATE
                 User.totaloil(d,TotalCoconut, TotalGroundnut, TotalSesame);
                 if (DateTime.Now.Hour == 24)
                 {
                     TotalSesame = 0;
                     TotalGroundnut = 0;
                     TotalCoconut = 0;
                 }

            }
            else if (dialog == DialogResult.No)
            {


            }



            printDocument1.Print();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            NewOrderButton.Enabled = true;
            PrintOrderButton.Enabled = false;
            PrintPreviewButton.Enabled = false;
            CancelOrderButton.Enabled = false;

            ItemGroupBox.Enabled = false;

            NametextBox.Clear();
            NumbertextBox.Clear();
            comboBox1.SelectedIndex = -1;
            PricetextBox.Clear();
            QuantitytextBox.Clear();
            TotaltextBox.Clear();

            TotalAmount = 0;
            TotalTax = 0;
            Totalvalue = 0;

            TaxtextBox.Clear();
            TotalPaytextBox.Clear();
            TotalAmounttextBox.Clear();
            dataGridView1.DataSource = null;
            shopping.Clear();
           




        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TotalAmounttextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
          
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

            address = richTextBox1.Text;


        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void TaxtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void PricetextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ItemGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void TotalPaytextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text.Equals("Coconut Oil"))
            {
                if (comboBox2.Text.Equals("1/2"))
                {
                    price = Convert.ToDecimal(130);
                    PricetextBox.Text = price.ToString();

                }
                if(comboBox2.Text.Equals("1"))
                {
                    price = Convert.ToDecimal(240);
                    PricetextBox.Text = price.ToString();
                }
                if (comboBox2.Text.Equals("2"))
                {
                    price = Convert.ToDecimal(480);
                    PricetextBox.Text = price.ToString();

                }
                if (comboBox2.Text.Equals("5"))
                {
                    price = Convert.ToDecimal(1200);
                    PricetextBox.Text = price.ToString();
                }
            }
            if (comboBox1.Text.Equals("Groundnut Oil"))
            {
                if (comboBox2.Text.Equals("1/2"))
                {
                    price = Convert.ToDecimal(145);
                    PricetextBox.Text = price.ToString();
                }
                if(comboBox2.Text.Equals("1"))
                {
                    price = Convert.ToDecimal(270);
                    PricetextBox.Text = price.ToString();
                }
                if (comboBox2.Text.Equals("2"))
                {
                    price = Convert.ToDecimal(540);
                    PricetextBox.Text = price.ToString();

                }
                if (comboBox2.Text.Equals("5"))
                {
                    price = Convert.ToDecimal(1350);
                    PricetextBox.Text = price.ToString();
                }
            }
            if (comboBox1.Text.Equals("Sesame Oil"))
            {
                if (comboBox2.Text.Equals("1/2"))
                {
                    price = Convert.ToDecimal(165);
                    PricetextBox.Text = price.ToString();
            
                }
                if (comboBox2.Text.Equals("1"))
                {
                    price = Convert.ToDecimal(270);
                    PricetextBox.Text = price.ToString();
                }
                if (comboBox2.Text.Equals("2"))
                {
                    price = Convert.ToDecimal(620);
                    PricetextBox.Text = price.ToString();

                }
                if (comboBox2.Text.Equals("5"))
                {
                    price = Convert.ToDecimal(1550);
                    PricetextBox.Text = price.ToString();
                }
                
            }
        }
    }
}
