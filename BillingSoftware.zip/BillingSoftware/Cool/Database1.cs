﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cool
{
   public static class Database1
    {


       static string database = "details";
       static string server = "localhost";
       static string username = "root";
       static string password = " ";
       static string connectionstring = "server=" + server + ";database="+database+";username=" + username + ";password=" + password + ";";
       public static MySqlConnection connection= null;


       //Constructor
       static Database1(){

           connection = new MySqlConnection(connectionstring);

   }
       public static bool Open()
       {
           try
           {
               connection.Open();
               return true;
           }
           catch (Exception e)
           {
               return false;
           }
       }
       public static bool Close()
       {
           try
           {
               connection.Close();
               return true;
           }
           catch (Exception e)
           {
               return false;
           }
       }
    }
}
